package com.thaiopensource.resolver.load;

/**
 *
 */
public class ResolverLoadException extends Exception {
  public ResolverLoadException(String message) {
    super(message);
  }

  public ResolverLoadException(Throwable cause) {
    super(cause);
  }
}
