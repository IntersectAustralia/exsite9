package com.thaiopensource.validate;

public class OptionArgumentFormatException extends OptionArgumentException {
  public OptionArgumentFormatException() {
  }

  public OptionArgumentFormatException(String message) {
    super(message);
  }
}
