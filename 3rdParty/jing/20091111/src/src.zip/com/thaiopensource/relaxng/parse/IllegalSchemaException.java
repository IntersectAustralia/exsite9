package com.thaiopensource.relaxng.parse;

public class IllegalSchemaException extends Exception { }
